cd /var/www/html/laravel && composer setup


/usr/bin/supervisord
