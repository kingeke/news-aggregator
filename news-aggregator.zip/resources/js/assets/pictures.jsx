import app_logo from './img/logo.jpg';

export const logo = <img alt="Logo" loading="lazy" width="80" height="80" src={app_logo} />;
export const appLogo = app_logo